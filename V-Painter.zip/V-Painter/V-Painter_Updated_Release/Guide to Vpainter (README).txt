ok, so to get started,choose colors and draw.

thats not what you need
you wanna know how to save it and stuff

press "save artwork as eps"
go to any file converter site like cloudconverter and convert the eps file you saved to png

WAZAAMMMMMMMM